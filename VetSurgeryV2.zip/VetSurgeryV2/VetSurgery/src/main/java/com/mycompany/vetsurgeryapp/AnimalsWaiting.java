package com.mycompany.vetsurgeryapp;


import java.util.ArrayList;

/** 
 *  
 *  @author Benny
 *  
 */

public class AnimalsWaiting  
{
    private ArrayList<Animal> animalsToBeSeen;
    public final int MAX;
        
    /** Constructor initialises the empty pet list and sets the maximum list size 
     *  @param   maxIn The maximum number of pet in the list
     */
    public AnimalsWaiting(int maxIn)
    {
        animalsToBeSeen = new ArrayList<>();
        MAX = maxIn;
    }
	
    /** Adds a new Pet to the list
     *  @param  myAnimal The Pet to add
     *  @return Returns true if the pet was added successfully and false otherwise
     */
    
    
    public boolean addAnimal(Animal myAnimal)
    {
        if(!isFull())
        {
            animalsToBeSeen.add(myAnimal);
            return true;
        }
        else
        {
            return false;
        }
    }
        


   /** Reports on whether or not the list is empty
     *  @return Returns true if the list is empty and false otherwise
     */
    public boolean isEmpty()
    {
        return animalsToBeSeen.isEmpty();
    }
	
    /** Reports on whether or not the list is full
     *  @return Returns true if the list is full and false otherwise
     */	
    public boolean isFull()
    {
        return animalsToBeSeen.size()== MAX;
    }
        
    /** Gets the total number of motorbikes 
     *  @return Returns the total number of pet currently in the list 
     */
    public int getTotal()
    {       
        return animalsToBeSeen.size();
    }
      
     /** Reads the bike at the given position in the list
     *  @param      positionIn The position of the pet in the list
     *  @return     Returns the pet at the  position in the list
     *              or null if no pet at that logical position
     */
    public Animal getTheAnimal(int positionIn)
    {
        if (positionIn < 0 || positionIn >= getTotal()) // check for valid position
        {
            return null; // no object found at given position
        }
        else
        {
            // remove one frm logical poition to get ArrayList position
            return animalsToBeSeen.get(positionIn);
        }
    }
    
     /** Outputs all the pet in the list
     *  @return     Returns all the pet and owners in the list in an easy to read format
     */
    
    public String displayTheAnimals()
    {
      String output = "\n";  
      for (int counter = 0; counter < animalsToBeSeen.size(); counter++) { 
          output += animalsToBeSeen.get(counter).ownerGivName + "\t" + animalsToBeSeen.get(counter).ownerSurname;
          output += "\n" + animalsToBeSeen.get(counter).animalID + "\t" + animalsToBeSeen.get(counter).species + "\t" + animalsToBeSeen.get(counter).animalName; 	
          output += "\n\n";
      } 
        return output;
    }
}


