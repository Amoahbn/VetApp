package com.mycompany.vetsurgeryapp;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * JavaFX App
 */
public class SurgeryInterface extends Application {

    private AnimalsWaiting animalsWaitingForVet;

    private final int WIDTH = 1300;
    private final int HEIGHT = 700;
    // visual components
    private final Label headingLabel = new Label("Book your pet");
    private final Label petLabel = new Label("Pet Details");
    private final Label regLabel = new Label("Pet registration number");
    private final TextField regField = new TextField();
    private final Label locationLabel = new Label("Location");
    private final TextField locationField = new TextField();
    private final Label dateLabel = new Label("Choose date");
    private final TextField dateField = new TextField();
    private final Label makeLabel = new Label("Species");
    private final TextField makeField = new TextField();
    private final Label idLabel = new Label("Pet name");
    private final TextField idField = new TextField();
    private final Separator sectSeparator = new Separator();
    private final Separator sectSeparator2 = new Separator();
    private final Separator sectSeparator3 = new Separator();
    private final Separator sectSeparator4 = new Separator();
    private final Label ownerLabel = new Label("Owner Details");
    private final Label nameLabel = new Label("First Name");
    private final TextField nameField = new TextField();
    private final Label surnameLabel = new Label("Last Name ");
    private final TextField surnameField = new TextField();
    private final TextArea displayAnimals = new TextArea();
    private final Button addButton = new Button("Book");

    @Override
    public void start(Stage stage) {

        animalsWaitingForVet = new AnimalsWaiting(30);

        HBox animalDetails = new HBox(10);
        HBox ownerDetails = new HBox(10);

        animalDetails.getChildren().addAll( regLabel, regField,locationLabel, locationField, dateLabel, dateField, makeLabel, makeField, idLabel, idField);

        ownerDetails.getChildren().addAll(nameLabel, nameField, surnameLabel, surnameField);

        // create VBox
        VBox root = new VBox(10);
        // add all components to VBox
        root.getChildren().addAll(headingLabel, sectSeparator, petLabel, animalDetails, sectSeparator2,
                ownerLabel, ownerDetails, sectSeparator3, displayAnimals, sectSeparator4, addButton);
        // create the scene

        // set font of heading
        Font font = new Font("Courier", 50);
        headingLabel.setFont(font);
        font = new Font("Times", 30);
        petLabel.setFont(font);
        ownerLabel.setFont(font);

        // set alignment of HBoxes
        animalDetails.setAlignment(Pos.BASELINE_CENTER);
        ownerDetails.setAlignment(Pos.TOP_CENTER);
        addButton.setAlignment(Pos.CENTER);

        // set alignment and Colour of  VBox 
        root.setAlignment(Pos.CENTER);
        root.setBackground(Background.EMPTY);
        // set minimum and maximum width of components

        displayAnimals.setMaxSize(800, 900);

        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);

        //addButton.setOnAction(e -> addHandler());
        // call private methods for button event handlers
        var javaVersion = SystemInfo.javaVersion();
        var javafxVersion = SystemInfo.javafxVersion();

        var label = new Label("Hello, JavaFX " + javafxVersion + ", running on Java " + javaVersion + ".");
        //var scene = new Scene(new StackPane(label), 640, 480);
        Scene scene = new Scene(root);
        scene.setFill(Color.web("#eede3c"));
        stage.setScene(scene);
        stage.setTitle(" Vet Surgery Booking System");
        // call private methods for button event handlers
        addButton.setOnAction(e -> addHandler());

        stage.show();
    }

    private void addHandler() {

        String animalReg = regField.getText();
        String area = locationField.getText();
        String species = makeField.getText();
        String animalName = idField.getText();
        String firstName = nameField.getText();
        String lastName = surnameField.getText();
        // check for errors
        if (animalReg.length() == 0 || species.length() == 0 || animalName.length() == 0) {
            displayAnimals.setText("You must fill the pet details");
        } else if (firstName.length() == 0 || lastName.length() == 0) {
            displayAnimals.setText("You must fill both your first name and last name");
        } else // ok to add a Tenant
        {
            Animal animalToAdd = new Animal(animalReg ,area ,species, animalName, firstName, lastName);
            animalsWaitingForVet.addAnimal(animalToAdd);
            //clear the fields
            locationField.setText("");
            regField.setText("");
            makeField.setText("");
            idField.setText("");
            nameField.setText("");
            surnameField.setText("");
            displayAnimals.setText("");
            displayAnimals.appendText(animalName + " is successfully added");
            displayAnimals.appendText("\n\nThe animal is awaiting to see the vet. Thank you! ");
            displayAnimals.appendText(animalsWaitingForVet.displayTheAnimals());
        }

    }

    public Label getregLabel() {
        return regLabel;
    }

    public TextField getregField() {
        return regField;
    }

    public static void main(String[] args) {
        launch();
    }

}
