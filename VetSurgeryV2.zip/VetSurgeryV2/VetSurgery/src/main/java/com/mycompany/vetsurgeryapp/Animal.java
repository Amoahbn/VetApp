package com.mycompany.vetsurgeryapp;


public class Animal {
    String animalID;
    String location;
    String species;
    String animalName;
    String ownerGivName;
    String ownerSurname;

    public Animal(String id, String area, String make, String name, String ownerGivName, String ownerSurname) {
        this.animalID = id;
        this.location = area;
        this.species = make;
        this.animalName = name;
        this.ownerGivName = ownerGivName;
        this.ownerSurname = ownerSurname;
    }    
}