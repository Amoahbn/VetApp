module com.mycompany.newbakovetsurgeryv2 {
    requires javafx.controls;
    exports com.mycompany.vetsurgeryapp;
}
